import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout.tsx";

import Home from "./pages/home/Home.tsx";
import Services from "./pages/services/services.tsx";
import Portfolio from "./pages/portfolio/portfolio.tsx";
import Contact from "./pages/contact/contact.tsx";



export default function App() {
  return (
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Layout>
  );
}
