import { useTranslation } from "react-i18next";

const Services = () => {
    const { t } = useTranslation();

    return (
        <section className="home-block" id="services">
            <div className="home-block-head">
                <h2 className="home-block-title">{t("home.sections.servicesTitle")}</h2>
            </div>

            <div className="home-services-list">
                <div className="home-services-item">
                    <div className="home-services-icon">✨</div>
                    <div className="home-services-name">{t("home.services.uiux")}</div>
                    <div className="home-services-desc">{t("home.services.uiuxDesc")}</div>
                </div>

                <div className="home-services-item">
                    <div className="home-services-icon">💻</div>
                    <div className="home-services-name">{t("home.services.web")}</div>
                    <div className="home-services-desc">{t("home.services.webDesc")}</div>
                </div>

                <div className="home-services-item">
                    <div className="home-services-icon">📱</div>
                    <div className="home-services-name">{t("home.services.mobile")}</div>
                    <div className="home-services-desc">{t("home.services.mobileDesc")}</div>
                </div>
            </div>
        </section>
    );
};

export default Services;
