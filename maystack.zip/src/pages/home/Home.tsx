



import "@fontsource/quicksand/400.css";
import "@fontsource/quicksand/500.css";
import "@fontsource/quicksand/600.css";
import "@fontsource/quicksand/700.css";


// import Intro from '../sections/intro.tsx'
import Hero from './hero.tsx'
import Services from "./services.tsx";
import Portfolio from "../portfolio/portfolio.tsx";
import Why from "./why.tsx"
import Contact from "../contact/contact.tsx"



export default function Home() {



    return (
        <div className="home">


            {/* HERO */}
            <Hero/>

            {/* OUR SERVICES */}
            <Services/>

            {/* PORTFOLIO */}
            <Portfolio/>

            {/* WHY MAYSTACK */}
            <Why/>

            {/* CONTACT */}
            <Contact/>


        </div>
    );
}
