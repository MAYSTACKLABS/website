import { NavLink, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useLanguage } from "../context/LanguageContext.tsx";
import { useEffect, useState } from "react";
import logoWhite from "./../assets/logos/white.png";

const NAV = [
    { key: "nav.home", to: "/" },
    { key: "nav.services", to: "/services" },
    { key: "nav.portfolio", to: "/portfolio" },
    { key: "nav.contact", to: "/contact" },
];

export default function Navbar() {
    const { t } = useTranslation();
    const { lang, toggleLang } = useLanguage();
    const [open, setOpen] = useState(false);

    const isRTL = lang === "ar";
    const location = useLocation();

    useEffect(() => {
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") setOpen(false);
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, []);

    const isActivePath = (to: string) => {
        if (to === "/") return location.pathname === "/";
        return location.pathname.startsWith(to);
    };

    const close = () => setOpen(false);

    return (
        <header className="topbar" dir={isRTL ? "rtl" : "ltr"}>
            <div className="topbar-inner">
                {/* keep navbar LTR so logo stays LEFT and actions stay RIGHT always */}
                <nav className={`nav-ms ${open ? "is-open" : ""}`} aria-label="Primary" dir="ltr">
                    {/* LEFT: logo */}
                    <NavLink to="/" className="nav-ms-brand" aria-label="Home" onClick={close}>
                        <img src={logoWhite} alt="Maystack" className="nav-ms-logo" />
                    </NavLink>

                    {/* CENTER: desktop links */}
                    <div className="nav-ms-links" dir={isRTL ? "rtl" : "ltr"}>
                        {NAV.map((item) => (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                onClick={close}
                                className={`nav-ms-link ${isActivePath(item.to) ? "is-active" : ""}`}
                            >
                                <span className="nav-ms-label">{t(item.key)}</span>
                            </NavLink>
                        ))}
                    </div>

                    {/* RIGHT: language + burger */}
                    <div className="nav-ms-actions" dir="ltr">
                        <button type="button" onClick={toggleLang} className="nav-ms-btn" aria-label="Toggle language">
                            {lang === "en" ? t("lang.ar") : t("lang.en")}
                        </button>

                        <button
                            type="button"
                            className="nav-ms-menu-btn"
                            aria-label={open ? "Close menu" : "Open menu"}
                            aria-expanded={open}
                            onClick={() => setOpen((v) => !v)}
                        >
                            {open ? "✕" : "☰"}
                        </button>
                    </div>

                    {/* MOBILE: links INSIDE SAME rounded navbar (no overlay / no drawer) */}
                    {open && (
                        <div className="nav-ms-mobile" dir={isRTL ? "rtl" : "ltr"}>
                            {NAV.map((item) => (
                                <NavLink
                                    key={item.to}
                                    to={item.to}
                                    onClick={close}
                                    className={`nav-ms-link ${isActivePath(item.to) ? "is-active" : ""}`}
                                >
                                    <span className="nav-ms-label">{t(item.key)}</span>
                                </NavLink>
                            ))}
                        </div>
                    )}
                </nav>
            </div>
        </header>
    );
}